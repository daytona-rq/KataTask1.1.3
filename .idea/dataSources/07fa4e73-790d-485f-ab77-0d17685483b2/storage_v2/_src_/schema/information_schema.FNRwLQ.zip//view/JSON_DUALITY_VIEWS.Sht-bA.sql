create view JSON_DUALITY_VIEWS as
select (`cat`.`name` collate utf8mb3_tolower_ci)                                                 AS `TABLE_CATALOG`,
       (`sch`.`name` collate utf8mb3_tolower_ci)                                                 AS `TABLE_SCHEMA`,
       (`tbl`.`name` collate utf8mb3_tolower_ci)                                                 AS `TABLE_NAME`,
       `tbl`.`view_definer`                                                                      AS `DEFINER`,
       if((`tbl`.`view_security_type` = 'DEFAULT'), 'DEFINER', `tbl`.`view_security_type`)       AS `SECURITY_TYPE`,
       `col`.`name`                                                                              AS `JSON_COLUMN_NAME`,
       (if(((0 <> can_access_table(`views`.`root_table_schema`, `views`.`root_table_name`)) and
            (0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`))),
           `views`.`root_table_catalog`, '') collate
        utf8mb4_0900_as_ci)                                                                      AS `ROOT_TABLE_CATALOG`,
       (if(((0 <> can_access_table(`views`.`root_table_schema`, `views`.`root_table_name`)) and
            (0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`))),
           `views`.`root_table_schema`, '') collate utf8mb4_0900_as_ci)                          AS `ROOT_TABLE_SCHEMA`,
       (if(((0 <> can_access_table(`views`.`root_table_schema`, `views`.`root_table_name`)) and
            (0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`))),
           `views`.`root_table_name`, '') collate utf8mb4_0900_as_ci)                            AS `ROOT_TABLE_NAME`,
       if(((0 <> can_access_table(`views`.`root_table_schema`, `views`.`root_table_name`)) and
           (0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`))),
          `views`.`allow_insert`, '')                                                            AS `ALLOW_INSERT`,
       if(((0 <> can_access_table(`views`.`root_table_schema`, `views`.`root_table_name`)) and
           (0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`))),
          `views`.`allow_update`, '')                                                            AS `ALLOW_UPDATE`,
       if(((0 <> can_access_table(`views`.`root_table_schema`, `views`.`root_table_name`)) and
           (0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`))),
          `views`.`allow_delete`, '')                                                            AS `ALLOW_DELETE`,
       if(((0 <> can_access_table(`views`.`root_table_schema`, `views`.`root_table_name`)) and
           (0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`))),
          `views`.`read_only`, '')                                                               AS `READ_ONLY`,
       if((get_dd_property_key_value(`tbl`.`options`, 'view_valid') = true), 'valid', 'invalid') AS `STATUS`
from ((((`mysql`.`columns` `col` join `mysql`.`tables` `tbl`
         on ((`col`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch`
        on ((`tbl`.`schema_id` = `sch`.`id`))) join `mysql`.`catalogs` `cat`
       on ((`cat`.`id` = `sch`.`catalog_id`))) join json_table(
        get_jdv_property_key_value(`sch`.`name`, `tbl`.`name`, get_dd_property_key_value(`tbl`.`options`, 'view_valid'),
                                   'JSON_DUALITY_VIEWS'), '$.entries[*]'
        columns (`root_table_catalog` varchar(64) character set utf8mb4 path '$.root_table_catalog', `root_table_schema` varchar(64) character set utf8mb4 path '$.root_table_schema', `root_table_name` varchar(64) character set utf8mb4 path '$.root_table_name', `allow_insert` tinyint path '$.allow_insert', `allow_update` tinyint path '$.allow_update', `allow_delete` tinyint path '$.allow_delete', `read_only` tinyint path '$.read_only')) `views`)
where ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) and (`tbl`.`type` = 'VIEW') and
       (get_dd_property_key_value(`tbl`.`options`, 'view_type') = 'JSON_DUALITY'));

