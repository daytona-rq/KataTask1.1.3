create view JSON_DUALITY_VIEW_TABLES as
select (`cat`.`name` collate utf8mb3_tolower_ci)                        AS `TABLE_CATALOG`,
       (`sch`.`name` collate utf8mb3_tolower_ci)                        AS `TABLE_SCHEMA`,
       (`tbl`.`name` collate utf8mb3_tolower_ci)                        AS `TABLE_NAME`,
       (`tables`.`referenced_table_catalog` collate utf8mb4_0900_as_ci) AS `REFERENCED_TABLE_CATALOG`,
       (`tables`.`referenced_table_schema` collate utf8mb4_0900_as_ci)  AS `REFERENCED_TABLE_SCHEMA`,
       (`tables`.`referenced_table_name` collate utf8mb4_0900_as_ci)    AS `REFERENCED_TABLE_NAME`,
       `tables`.`where_clause`                                          AS `WHERE_CLAUSE`,
       `tables`.`allow_insert`                                          AS `ALLOW_INSERT`,
       `tables`.`allow_update`                                          AS `ALLOW_UPDATE`,
       `tables`.`allow_delete`                                          AS `ALLOW_DELETE`,
       `tables`.`read_only`                                             AS `READ_ONLY`,
       `tables`.`is_root_table`                                         AS `IS_ROOT_TABLE`,
       `tables`.`referenced_table_id`                                   AS `REFERENCED_TABLE_ID`,
       `tables`.`referenced_table_parent_id`                            AS `REFERENCED_TABLE_PARENT_ID`,
       `tables`.`referenced_table_parent_relationship`                  AS `REFERENCED_TABLE_PARENT_RELATIONSHIP`
from (((`mysql`.`tables` `tbl` join `mysql`.`schemata` `sch`
        on ((`tbl`.`schema_id` = `sch`.`id`))) join `mysql`.`catalogs` `cat`
       on ((`cat`.`id` = `sch`.`catalog_id`))) join json_table(
        get_jdv_property_key_value(`sch`.`name`, `tbl`.`name`, get_dd_property_key_value(`tbl`.`options`, 'view_valid'),
                                   'JSON_DUALITY_VIEW_TABLES'), '$.entries[*]'
        columns (`referenced_table_id` int path '$.referenced_table_id', `referenced_table_parent_id` int path '$.referenced_table_parent_id', `referenced_table_parent_relationship` varchar(64) character set utf8mb4 path '$.referenced_table_parent_relationship', `referenced_table_catalog` varchar(64) character set utf8mb4 path '$.referenced_table_catalog', `referenced_table_schema` varchar(64) character set utf8mb4 path '$.referenced_table_schema', `referenced_table_name` varchar(64) character set utf8mb4 path '$.referenced_table_name', `where_clause` varchar(64) character set utf8mb4 path '$.where_clause', `is_root_table` tinyint path '$.is_root_table', `allow_insert` tinyint path '$.allow_insert', `allow_update` tinyint path '$.allow_update', `allow_delete` tinyint path '$.allow_delete', `read_only` tinyint path '$.read_only')) `tables`)
where ((0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`)) and
       (0 <> can_access_table(`tables`.`referenced_table_schema`, `tables`.`referenced_table_name`)) and
       (`tbl`.`type` = 'VIEW') and (get_dd_property_key_value(`tbl`.`options`, 'view_type') = 'JSON_DUALITY'));

